import React from 'react'
function Footer() {
  return (
  <section>
    <div className='container'>
     
      </div>

    </section>
  )
}

export default Footer