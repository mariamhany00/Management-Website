import { Fragment } from "react"
import Landing from "../components/Landing"
import Features from "../components/Features"
import Stay from "../components/Stay"
import Test from "../components/Test"

function Home() {
  return (
   <Fragment>
    <Landing/>
    <Features/>
   <Stay/>
   <Test/>
   </Fragment>
  )
}

export default Home