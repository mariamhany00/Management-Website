// Landing.js
import React from 'react';
import landing from '../assets/images/Landing.png';

function Landing() {
  return (
    <section>
      <div className='container'>
       <div className='element-center pt-[150px]'>
       <div className='w-[750px] max-w-full'> 
          <img src={landing} alt="Landing Page" className='w-full h-fit' />
        </div>
        <div className='text-white text-center'>
          <h1 className='text-[30px] md:text-[40px] font-semibold mb-[15px]'>Tasks</h1>
          <p className='font-normal text-lg px-[15px] md:w-[600px] max-w-full md:mx-auto'>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam provident, dolor iure deserunt quas autem est expedita at sit sapiente blanditiis cum? In id provident recusandae reiciendis ea, corporis illo?
          </p>
        </div>
        <a href='/' className='btn w-[200px] h-[50px]  rounded-[30px] element-center  mt-[10px] text-white font-medium'>
  Get Started 
</a>

   
       </div>
      </div>
      <div className='w-full h-[200px'>
                <img src='/src/assets/images/bg-curvy-desktop.svg ' className='w-full h-full'
                >
                </img>

            </div>
    </section>
  );
}

export default Landing;
