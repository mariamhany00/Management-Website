import React, { useState } from 'react';
import FeatureBox from './FeatureBox';

function Features() {
    const [items, setItems] = useState([
        {
            icon: "icon-access-anywhere.svg",
            title: "Access your files anywhere",
            desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
        },
        {
            icon: "icon-collaboration.svg",
            title: "Collaborate with your team",
            desc: "Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."
        },
        {
            icon: "icon-any-file.svg",
            title: "Store any file type",
            desc: "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        },
        {
            icon: "icon-security.svg",
            title: "Store any file type",
            desc: "Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
        }

    ]);

    return (
        <section className='pb-[150px]'>
            <div className='container'>
                <div className='grid grid-cols-1 md:grid-cols-2 gap-[100px] w-[865px] mx-auto max-w-full'>
                    {items.map(item => (
                        <FeatureBox key={item.title} icon={item.icon} title={item.title} desc={item.desc} />
                    ))}
                </div>
            </div>
            
        </section>
    );
}

export default Features;
