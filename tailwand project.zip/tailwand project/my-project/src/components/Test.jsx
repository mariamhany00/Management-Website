import React, { useState } from 'react';
import TestBox from './TestBox';

function Test() {
    const [testData, setData] = useState([
        {
            id: 1,
            desc: "Backend development also involves working with databases to store and retrieve data, as well as managing user authentication, security, and scalability aspects of the application.",
            image: "profile-1.jpg",
            position: "Backend Developer",
            name: "hany"
        },
        {
            id: 2,
            desc: "Frontend developers need to have a good understanding of design principles, usability, and accessibility standards to create interfaces that are intuitive and easy to use for a wide range of users.",
            image: "profile-2.jpg",
            position: "React Js Developer",
            name: "habib"
        },
        {
            id: 3,
            desc: "Full stack developers often work on projects independently or as part of a team, where they can contribute to different parts of the development process and take on various roles depending on the project requirements.",
            image: "profile-3.jpg",
            position: "Full Stack Developer",
            name: "mariam"
        }
    ]);

    return (
        <section className='pb-[350px]'>  
            <div className='container '>
                <div className='grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-[40px]'>
                    {testData.map((item) => (
                        <TestBox key={item.id} desc={item.desc} image={item.image} position={item.position} name={item.name} />
                    ))}
                </div>
            </div>
        </section>
    );
}

export default Test;

