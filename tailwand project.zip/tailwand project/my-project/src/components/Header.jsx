import { useEffect, useRef, useState } from 'react';
import logo from '../assets/images/logo.svg';

function Header() {
  const [links, setLinks] = useState(["Features", "Team", "Signin"]); 
  const headerRef=useRef();
  useEffect(()=>{
 window.addEventListener("scroll",()=>{

  if(window.scrollY>100){
    headerRef.current.style.background="rgb(17 24 39)"
    headerRef.current.style.padding="20px 0"
  }else{
    headerRef.current.style.background="transparent"
    headerRef.current.style.padding="60px 0"
  }

 })
  },[])

  return (

    <header ref={headerRef}
    className='pt-[60px] fixed top-0 left-0 w-full z-50 transation-all duration-200' >
        <div className='container  flex justify-between items-center gap-[30] sm:gap-0 flex-col sm:flex-row'>
      <a href='/'>
        <img src={logo} alt="Logo" />
      </a>
      <nav>
        <ul className='flex items-center gap-[50px]'>
          {links.map((link) => (
            <li key={link}>
              <a href={`/${link.toLowerCase()}`} className='text-white opacity-[0.9] hover:opacity-[1] hover:underline transation-opacity duration-200' >{link}</a>
            </li>
          ))}
        </ul>
      </nav>
      </div>
    </header>
  );
}

export default Header;
