import React from 'react';

function Stay() {
  return (
    <section className='pb-[150px]'>
    <div className='container grid grid-cols-1 md:grid-cols-2 gap-8 place-items-center'>
      <div>
        <img src='/src/assets/images/illustration-stay-productive.png' alt="Stay Productive Illustration" />
      </div>
      <div className='text-white'>
        <h3 className='font-medium text-3xl leading-10 mb-2'>
          Stay Productive
          <br />
          Wherever you are
        </h3>
        <div className='my-2 font-normal text-sm'>
          <p className='mb-2'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia nam doloremque sit. Blanditiis exercitationem rerum illum maiores, repudiandae repellendus. Neque nisi dolore mollitia obcaecati nostrum aperiam voluptatum exercitationem debitis dolorum!</p>
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Suscipit quisquam eligendi iusto ipsa sapiente, praesentium velit incidunt! Maiores eos ea dolores commodi rem! Itaque, sit rerum deserunt culpa laudantium dignissimos?</p>
        </div>
        <a href='/' className='text-primary hover:text-blue-500 flex items-center gap-2 transition-colors duration-200'>
          See how fylo works
          <img src='/src/assets/images/icon-arrow.svg' className='w-5 h-5 object-contain  animate-moveRight' alt="Arrow Icon"  />
        </a>
      </div>
    </div>
    </section>
  );
}

export default Stay;


